//
//  ContentView.swift
//  ApplePayButtonSession
//
//  Created by admin on 2025/7/7.
//  https://www.youtube.com/watch?v=BGGcu-rRfro
//  Apple Pay Button Using SwiftUI


import SwiftUI
import PassKit

struct Product: Identifiable {
    let id: UUID = UUID()
    let name: String
    let price: Double
}


struct ContentView: View {
    let products: [Product] = [Product(name: "T-shirt", price: 20.0),Product(name: "Watch", price: 80.0)]
    var body: some View {
        PaymentButton(products: products)
            .frame(minWidth: 100,maxWidth: .infinity,maxHeight:45)
            .padding()
    }
}

struct  ContentView_Preview:PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct PaymentButton: UIViewRepresentable {
    
    var products:[Product]
    
    func makeCoordinator() -> PaymentManger {
        PaymentManger(products: products)
    }
    
    func makeUIView(context: Context) -> PKPaymentButton {
        context.coordinator.button
    }
    
    func updateUIView(_ uiView: PKPaymentButton, context: Context) {
        context.coordinator.products = products
    }
}

class PaymentManger: NSObject, PKPaymentAuthorizationViewControllerDelegate{

    var products:[Product]
    var button = PKPaymentButton(paymentButtonType: .buy, paymentButtonStyle: .automatic)
    
    init(products:[Product]){
        self.products = products
        super.init( )
        button.addTarget(self, action: #selector(callBack(_:)), for: .touchUpInside)
    }
    
   @objc func callBack(_ sender: Any?) {
        startPayment(product:products)
    }
    
    func startPayment(product:[Product]){
        
        var paymentController: PKPaymentAuthorizationViewController?
        var paymentsummartItems = [PKPaymentSummaryItem]()
        
        var totalPrice:Double = 0
        products.forEach { (product) in
            let item = PKPaymentSummaryItem(label: product.name, amount: NSDecimalNumber(value: product.price))
            paymentsummartItems.append(item)
            totalPrice += product.price
        }
        
        let total = PKPaymentSummaryItem(label: "Total", amount: NSDecimalNumber(string:"\(totalPrice)"),type: .final)
        paymentsummartItems.append(total)
        
        var paymentRequest = PKPaymentRequest()
        
        paymentRequest.paymentSummaryItems = paymentsummartItems
        paymentRequest.countryCode = "SA"
        paymentRequest.currencyCode = "SAR"
        paymentRequest.supportedNetworks = [.amex, .masterCard, .visa, .mada]
        paymentRequest.merchantIdentifier = "merchant.example.apple-pay"
        paymentRequest.merchantCapabilities = .threeDSecure
        paymentRequest.shippingMethods = shippingMethodCaculator()
        paymentRequest.requiredShippingContactFields = [.name,.phoneNumber]
        
        // Present the payment authorization view controller
        paymentController = PKPaymentAuthorizationViewController(paymentRequest: paymentRequest)
        paymentController?.delegate = self
        
        if let paymentController = paymentController {
            // You'll need to present this from your view controller
            // This is a simplified example - you'll need to get the current view controller
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first,
               let rootViewController = window.rootViewController {
                rootViewController.present(paymentController, animated: true)
            }
        }
    }
    
    func shippingMethodCaculator() ->[PKShippingMethod]{
        let today = Date()
        let calendar = Calendar.current
        let shippingStart = calendar.date(byAdding: .day, value: 5, to: today)
        let shippingEnd = calendar.date(byAdding: .day, value: 10, to: today)
        
        if let shippingEnd = shippingEnd, let shippingStart = shippingStart {
            let startComponets = calendar.dateComponents(in: .current, from: shippingStart)
            let endComponets = calendar.dateComponents(in: .current, from: shippingEnd)
            let shippingDelivery = PKShippingMethod(label: "Delivery", amount: NSDecimalNumber(string: "0.00"))
            
            shippingDelivery.dateComponentsRange = PKDateComponentsRange(start: startComponets, end: endComponets)
            shippingDelivery.detail = "Delivered within 5-10 business days"
            shippingDelivery.identifier = "delivery"
            
            return [shippingDelivery]
            
        }
        
        return []
    }
    
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController, didAuthorizePayment payment: PKPayment) async -> PKPaymentAuthorizationResult {
        .init(status: .success, errors: nil)
    }

    func paymentAuthorizationViewControllerDidFinish(_ controller: PKPaymentAuthorizationViewController) {
        controller.dismiss(animated: true)
    }

}
