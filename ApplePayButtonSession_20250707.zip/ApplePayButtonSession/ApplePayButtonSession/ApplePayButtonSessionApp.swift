//
//  ApplePayButtonSessionApp.swift
//  ApplePayButtonSession
//
//  Created by admin on 2025/7/7.
//

import SwiftUI

@main
struct ApplePayButtonSessionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
