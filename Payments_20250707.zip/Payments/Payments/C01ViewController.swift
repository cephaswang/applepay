//
//  C01ViewController.swift
//  Payments
//
//  Created by admin on 2025/7/7.
/*
 
https://www.youtube.com/watch?v=w6OT9qaV3E4
Apple Pay in iOS with Swift 5

request.merchantIdentifier 如何生成？
Apple Pay 证书需要定期更新（通常每年），否则支付功能可能失效。

https://www.youtube.com/watch?v=AJ6zNhYYkG8
How To Setting Apple Pay Integration and App Signing With An Apple Developer Account

*/


import UIKit
import PassKit

class C01ViewController: UIViewController {

    @IBOutlet weak var btn_pay: UIButton!
    
    private var paymentRequest: PKPaymentRequest = {
        let request = PKPaymentRequest()
        
        request.merchantIdentifier = "merchant.example.com"
        request.supportedNetworks = [.amex, .masterCard, .visa, .quicPay]
        request.supportedCountries = ["IN","US"]
        request.merchantCapabilities = .capability3DS
        request.countryCode = "IN"
        request.currencyCode = "INR"
        
        request.paymentSummaryItems = [PKPaymentSummaryItem(label: "iPhone XR 128 GB", amount: 123000)]
        return request
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func tapForPay(_ sender: Any) {
        let controller = PKPaymentAuthorizationViewController(paymentRequest: paymentRequest)
        if controller != nil {
            controller!.delegate = self
            present(controller!, animated: true){
                print("Completed")
            }
        }
    }
    
}

extension C01ViewController: PKPaymentAuthorizationViewControllerDelegate {
    func paymentAuthorizationViewControllerDidFinish(_ controller: PKPaymentAuthorizationViewController) {
        controller.dismiss(animated: true)
        print("paymentAuthorizationViewControllerDidFinish")
    }
    
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController,
                                           didAuthorizePayment payment: PKPayment,
                                           handler completion: @escaping (PKPaymentAuthorizationResult) -> Void) {
        let result = PKPaymentAuthorizationResult(status: .success, errors: nil)
        completion(result)
        
        // Print meaningful details of the result
        let statusDescription = result.status == .success ? "Success" : "Failure"
        let errorsDescription = result.errors?.map { $0.localizedDescription }.joined(separator: ", ") ?? "No errors"
        print("Payment Authorization Result: Status = \(statusDescription), Errors = \(errorsDescription)")
    }
}
