//
//  ViewController.swift
//  Payments
//
//  Created by admin on 2025/7/7.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

