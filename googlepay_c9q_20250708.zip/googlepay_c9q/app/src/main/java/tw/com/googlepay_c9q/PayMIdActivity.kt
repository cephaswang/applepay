package tw.com.googlepay_c9q

import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Task
import com.google.android.gms.wallet.*
import com.google.android.gms.wallet.WalletConstants.*
import org.json.JSONArray
import org.json.JSONObject

/*
https://www.youtube.com/watch?v=SZorG5Hqjzc
Google Pay API implementation demo (Android)

https://youtu.be/rP_UAPcIG4I?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=2
Google Pay API Explained

https://youtu.be/pZyGYUMZAeg?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=40
Google Pay API Implementation Demo (Web)

https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=41
Google Pay API implementation demo (Android)

google merchant center
https://www.google.com/retail/

https://merchants.google.com/mc/settings/

g.co/pay/sign-up
https://pay.google.com/business/console/home/

g.co/pay/api
https://developers.google.com/pay/api?hl=zh-tw

g.co/pay/android-api-branding
https://developers.google.com/pay/api/android/guides/brand-guidelines?hl=zh-tw
*/

class PayMIdActivity : AppCompatActivity() {

    // 支付按鈕
    private lateinit var googlePayButton: Button

    // https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=68
    // 定義一個私有屬性，用於儲存 PaymentsClient 實例
    private lateinit var paymentsClient: PaymentsClient

    // Request code for payment data
    private val LOAD_PAYMENT_DATA_REQUEST_CODE = 991

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pay_mid)

        googlePayButton = findViewById(R.id.googlePayButton)
        googlePayButton.visibility = View.INVISIBLE

        // 創建 WalletOptions，設定支付環境
        val walletOptions = Wallet.WalletOptions.Builder()
            // 設定為測試環境（WalletConstants.ENVIRONMENT_TEST）
            .setEnvironment(ENVIRONMENT_TEST)
            // 構建 WalletOptions 物件
            .build()

        // 初始化 PaymentsClient，用於處理支付相關操作
        paymentsClient = Wallet.getPaymentsClient(
            this, // 傳入當前 Activity 的上下文
            walletOptions // 傳入配置好的 WalletOptions
        )

        // https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=131
        // 創建 IsReadyToPayRequest 物件，用於檢查設備是否準備好進行支付
        val readyToPayRequest: IsReadyToPayRequest = IsReadyToPayRequest.fromJson(baseConfigurationJson().toString())

        // 呼叫 paymentsClient 的 isReadyToPay 方法，檢查支付準備狀態
        val task: Task<Boolean> = paymentsClient.isReadyToPay(readyToPayRequest)

        // 為 task 添加完成監聽器，處理檢查結果
        task.addOnCompleteListener(this) { completeTask ->
            if (completeTask.isSuccessful) {
                Log.d("isReadyToPay","支付準備就緒")
                // 支付準備就緒，可以顯示 Google Pay 按鈕或進行後續支付流程
                // 例如：顯示支付按鈕或提示用戶可以進行支付
                showGooglePayButton(completeTask.result)
               // googlePayButton.visibility = View.VISIBLE
            } else {
                Log.d("isReadyToPay","支付準備失敗")
                // 支付準備失敗，處理錯誤情況
                // 例如：隱藏支付按鈕或顯示錯誤訊息
                Toast.makeText(this, "Google Pay is not available", Toast.LENGTH_LONG).show()
                googlePayButton.visibility = View.GONE
            }
        }

        // Set up Google Pay button click listener to initiate payment
        googlePayButton.setOnClickListener {
            Log.d("googlePayButton","googlePayButton");
            initiatePayment()
        }
    }

    // Initiate Google Pay payment
    private fun initiatePayment() {
        // 創建支付請求的 JSONObject，基於基礎配置並添加交易和商家資訊
        val paymentRequestJson = baseConfigurationJson().apply {
            // 添加交易資訊
            put("transactionInfo", JSONObject().apply {
                // 設定交易總金額，例如 123.45
                put("totalPrice", "123.45")
                // 設定總金額狀態為最終金額（FINAL）
                put("totalPriceStatus", "FINAL")
                // 設定貨幣代碼為美元（USD）
                put("currencyCode", "USD")
                // 設定國家代碼為美國
                put("countryCode", "US")
            })
            // 添加商家資訊
            put("merchantInfo", JSONObject().apply {
                // 設定商家 ID，唯一識別商家
                put("merchantId", "01234567890123456789")
                // 設定商家名稱，顯示在支付介面上
                put("merchantName", "Example Merchant")
            })
            // 添加郵件地址要求
            put("emailRequired", true)
        }

        // https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=257
        // 創建 PaymentDataRequest 物件，用於發起 Google Pay 支付請求
        val request = PaymentDataRequest.fromJson(paymentRequestJson.toString())

        // 使用 AutoResolveHelper 解析支付任務，啟動 Google Pay 支付流程
        AutoResolveHelper.resolveTask(
            paymentsClient.loadPaymentData(request), // 通過 paymentsClient 載入支付資料
            this, // 傳入當前 Activity 的上下文
            LOAD_PAYMENT_DATA_REQUEST_CODE // 自定義的請求碼，用於識別支付結果
        )
    }

    // Handle payment result
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == LOAD_PAYMENT_DATA_REQUEST_CODE) {
            when (resultCode) {
                RESULT_OK -> {
                    data?.let { intent ->
                        PaymentData.getFromIntent(intent)?.let { paymentData ->
                            val paymentInfo = paymentData.toJson()
                            // Process the payment token (e.g., send to your payment processor)
                            try {
                                val paymentToken = JSONObject(paymentInfo).getJSONObject("paymentMethodData")
                                    .getJSONObject("tokenizationData").getString("token")
                                Toast.makeText(this, "Payment successful! Token: $paymentToken", Toast.LENGTH_LONG).show()

                                // Play success sound
                                val notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                                RingtoneManager.getRingtone(this, notification).play()
                            } catch (e: Exception) {
                                Toast.makeText(this, "Payment processed but token parsing failed", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
                RESULT_CANCELED -> {
                    Toast.makeText(this, "Payment cancelled", Toast.LENGTH_SHORT).show()
                }
                AutoResolveHelper.RESULT_ERROR -> {
                    AutoResolveHelper.getStatusFromIntent(data)?.let { status ->
                        Toast.makeText(this, "Error: ${status.statusMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    // https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=215
    // 定義一個私有靜態函數，用於生成卡片支付方式的 JSONObject
    private fun getCardPaymentMethod(): JSONObject {
        // 定義支援的卡片網路陣列，例如 VISA 和 AMEX
        val networks = arrayOf("VISA", "AMEX", "MASTERCARD", "DISCOVER", "JCB")
        // 定義支援的認證方法陣列，例如僅用卡號（PAN_ONLY）或 3D 安全認證（CRYPTOGRAM_3DS）
        val authMethods = arrayOf("PAN_ONLY", "CRYPTOGRAM_3DS")

        // 創建一個 JSONObject 來表示卡片支付方式
        return JSONObject().apply {
            // 設定支付方式類型為 "CARD"
            put("type", "CARD")
            // 設定 tokenization 規格，調用 getTokenizationSpec() 函數獲取相關配置
            put("tokenizationSpecification", getTokenizationSpec())
            // 設定卡片參數，包括允許的認證方法和卡片網路
            put("parameters", JSONObject().apply {
                // 添加允許的認證方法陣列
                put("allowedAuthMethods", JSONArray(authMethods))
                // 添加允許的卡片網路陣列
                put("allowedCardNetworks", JSONArray(networks))
                // Require assurance details for security
                put("assuranceDetailsRequired", true)
                // Require billing address
                put("billingAddressRequired", true)
                put("billingAddressParameters", JSONObject().apply {
                    put("format", "MIN")
                    put("phoneNumberRequired", false)
                })
            })
        }
    }

    // Generate tokenization specification for payment gateway
    private fun getTokenizationSpec(): JSONObject {
        return JSONObject().apply {
            put("type", "PAYMENT_GATEWAY")
            put("parameters", JSONObject().apply {
                // For testing, use "example" as gateway
                put("gateway", "example")
                // For testing, use "exampleGatewayMerchantId" as gateway merchant ID
                put("gatewayMerchantId", "exampleGatewayMerchantId")
                // Add protocol version for testing
                put("gatewayMerchantId", "exampleGatewayMerchantId")
            })
        }
    }

    // https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=156
    // 定義一個私有靜態函數，用於生成 Google Pay 支付基礎配置的 JSONObject
    private fun baseConfigurationJson(): JSONObject {
        return JSONObject().apply {
            // 設定 Google Pay API 的主要版本號為 2
            put("apiVersion", 2)
            // 設定 Google Pay API 的次要版本號為 0
            put("apiVersionMinor", 0)
            // 設定允許的支付方式，包含卡片支付方式
            put(
                "allowedPaymentMethods",
                JSONArray().apply {
                    // 添加卡片支付方式，調用 getCardPaymentMethod() 函數
                    put(getCardPaymentMethod())
                }
            )
        }
    }

    // https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=169
    // 定義一個私有函數，用於根據支付準備狀態顯示或隱藏 Google Pay 按鈕
    private fun showGooglePayButton(userIsReadyToPay: Boolean) {
        Log.d("userIsReadyToPay",userIsReadyToPay.toString())
        // 用戶已準備好使用 Google Pay，更新 UI 以顯示 Google Pay 按鈕
        // 例如：googlePayButton.visibility = View.VISIBLE
        // Google Pay 不受支援，不顯示按鈕
        // 例如：googlePayButton.visibility = View.GONE
        googlePayButton.visibility = if (userIsReadyToPay) View.VISIBLE else View.INVISIBLE
        googlePayButton.isEnabled = userIsReadyToPay  // Add this line
    }
}