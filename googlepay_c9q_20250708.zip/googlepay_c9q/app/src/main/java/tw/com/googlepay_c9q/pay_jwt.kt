package tw.com.googlepay_c9q

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.pay.Pay
import com.google.android.gms.pay.PayClient

class pay_jwt : AppCompatActivity() {

    private lateinit var payClient: PayClient
    private lateinit var btnAddToWallet: Button
    private val ADD_TO_WALLET_REQUEST_CODE = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pay_jwt)

        payClient = Pay.getClient(this)
        btnAddToWallet = findViewById(R.id.btnAddToWallet)

        btnAddToWallet.setOnClickListener {
            val jwt = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ5b3VyLWlzc3Vlci1pZEBnb29nbGUuY29tIiwiYXVkIjoiZ29vZ2xlIiwidHlwIjoic2F2ZXRvd2FsbGV0IiwiaWF0IjoxNzIwMzk4MDk1LCJwYXlsb2FkIjp7ImdlbmVyaWNPYmplY3RzIjpbeyJpZCI6InlvdXItaXNzdWVyLWlkLjEyMzQ1Njc4OSIsImNsYXNzSWQiOiJ5b3VyLWlzc3Vlci1pZC5nZW5lcmljLWNsYXNzIiwiZ2VuZXJpY1R5cGUiOiJHRU5FUklDX1RZUEVfVU5TUEVDSUZJRUQiLCJjYXJkVGl0bGUiOnsiZGVmYXVsdFZhbHVlIjp7Imxhbmd1YWdlIjoiZW4iLCJ2YWx1ZSI6Ilx1NmVhYlx1N2I1M1x1N2Y4OCJ9fSwiaGV4QmFja2dyb3VuZENvbG9yIjoiI0ZGRkZGRiJ9XX19"
            payClient.savePasses(jwt, this, ADD_TO_WALLET_REQUEST_CODE)
        }

        /*
        btnAddToWallet.setOnClickListener {
            val jwt = "YOUR_JWT_STRING_FROM_BACKEND" // Replace with actual JWT
            payClient.savePasses(jwt, this, ADD_TO_WALLET_REQUEST_CODE)
        }
        */
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ADD_TO_WALLET_REQUEST_CODE) {
            when (resultCode) {
                Activity.RESULT_OK -> {
                    Toast.makeText(this, "Pass successfully added to Google Wallet", Toast.LENGTH_LONG).show()
                }
                Activity.RESULT_CANCELED -> {
                    Toast.makeText(this, "User canceled the operation", Toast.LENGTH_LONG).show()
                }
                else -> {
                    Toast.makeText(this, "Failed to add pass to Google Wallet", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}