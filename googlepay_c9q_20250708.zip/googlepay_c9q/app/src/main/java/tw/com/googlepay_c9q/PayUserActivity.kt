package tw.com.googlepay_c9q

import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.wallet.*
import com.google.android.gms.wallet.WalletConstants.*
import org.json.JSONArray
import org.json.JSONObject

/*
https://www.youtube.com/watch?v=SZorG5Hqjzc
Google Pay API implementation demo (Android)


https://youtu.be/rP_UAPcIG4I?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=2
Google Pay API Explained

https://youtu.be/pZyGYUMZAeg?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=40
Google Pay API Implementation Demo (Web)

https://youtu.be/SZorG5Hqjzc?list=PLNYkxOF6rcIByfPlehsS6nJyXXPkgtKtY&t=41
Google Pay API implementation demo (Android)


google merchant center
https://www.google.com/retail/

https://merchants.google.com/mc/settings/

g.co/pay/sign-up
https://pay.google.com/business/console/home/

g.co/pay/api
https://developers.google.com/pay/api?hl=zh-tw

g.co/pay/android-api-branding
https://developers.google.com/pay/api/android/guides/brand-guidelines?hl=zh-tw


*/

class PayUserActivity : AppCompatActivity() {

    // 支付客戶端，用於與Google Pay API交互
    private lateinit var paymentsClient: PaymentsClient
    // 支付按鈕
    private lateinit var payButton: Button

    // 支付閘道令牌化參數配置
    private val gatewayTokenizationParameters = JSONObject().apply {
        put("gateway", "example") // 支付閘道名稱（如：stripe、braintree等）
        put("gatewayMerchantId", "exampleGatewayMerchantId") // 支付閘道商戶ID
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pay_user)

        // 初始化支付按鈕
        payButton = findViewById(R.id.pay_button)
        payButton.isEnabled = false // 初始禁用按鈕，直到確認Google Pay可用
        payButton.setOnClickListener { requestPayment() } // 設置點擊事件

        // 初始化錢包選項（測試環境）
        val walletOptions = Wallet.WalletOptions.Builder()
            .setEnvironment(ENVIRONMENT_TEST) // 設置為測試環境，上線需改為ENVIRONMENT_PRODUCTION
            .build()

        // 初始化PaymentsClient
        paymentsClient = Wallet.getPaymentsClient(this, walletOptions)

        // 檢查Google Pay是否可用
        checkGooglePayAvailability()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            LOAD_PAYMENT_DATA_REQUEST_CODE -> { // 處理支付結果
                when (resultCode) {
                    RESULT_OK -> { // 支付成功
                        data?.let { intent ->
                            PaymentData.getFromIntent(intent)?.let { paymentData ->
                                handlePaymentSuccess() // 處理支付成功邏輯
                            }
                        }
                    }
                    RESULT_CANCELED -> { // 用戶取消支付
                        Toast.makeText(
                            this,
                            "Payment cancelled", // 支付已取消
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    AutoResolveHelper.RESULT_ERROR -> { // 支付失敗
                        AutoResolveHelper.getStatusFromIntent(data)?.let { status ->
                            Toast.makeText(
                                this,
                                "Payment failed: ${status.statusMessage}", // 支付失敗提示
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        }
    }

    // 處理支付成功後的邏輯
    private fun handlePaymentSuccess() {
        playSuccessSound() // 播放成功音效

        Toast.makeText(
            this,
            "Payment successful!", // 支付成功提示
            Toast.LENGTH_LONG
        ).show()

        // 這裡可以添加：
        // 1. 更新訂單狀態
        // 2. 發送收據給用戶
        // 3. 通知後台系統
    }

    // 播放成功音效
    private fun playSuccessSound() {
        try {
            val notificationUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone = RingtoneManager.getRingtone(applicationContext, notificationUri)
            ringtone.play() // 播放系統預設通知音效
        } catch (e: Exception) {
            e.printStackTrace() // 捕獲並打印異常
        }
    }

    // 檢查Google Pay是否可用
    private fun checkGooglePayAvailability() {
        val request = IsReadyToPayRequest.fromJson(createIsReadyToPayJson().toString())

        paymentsClient.isReadyToPay(request)
            .addOnCompleteListener { task ->
                if (task.isSuccessful && task.result == true) {
                    payButton.isEnabled = true // 啟用支付按鈕
                } else {
                    Toast.makeText(
                        this,
                        "Google Pay is not available", // Google Pay不可用提示
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }

    // 發起支付請求
    private fun requestPayment() {
        val paymentDataRequest = createPaymentDataRequest()
        val request = PaymentDataRequest.fromJson(paymentDataRequest.toString())

        // 使用AutoResolveHelper自動處理支付流程
        AutoResolveHelper.resolveTask(
            paymentsClient.loadPaymentData(request),
            this,
            LOAD_PAYMENT_DATA_REQUEST_CODE
        )
    }

    // 創建檢查Google Pay可用性的JSON配置
    private fun createIsReadyToPayJson(): JSONObject {
        return JSONObject().apply {
            put("apiVersion", 2) // API主版本
            put("apiVersionMinor", 0) // API次版本

            // 配置允許的支付方式
            val allowedPaymentMethods = JSONArray().put(
                JSONObject().apply {
                    put("type", "CARD") // 卡支付
                    put("parameters", JSONObject().apply {
                        // 允許的認證方式
                        put("allowedAuthMethods", JSONArray(listOf("PAN_ONLY", "CRYPTOGRAM_3DS")))
                        // 允許的卡網絡
                        put("allowedCardNetworks", JSONArray(listOf("AMEX", "DISCOVER", "MASTERCARD", "VISA")))
                    })
                }
            )

            put("allowedPaymentMethods", allowedPaymentMethods)
        }
    }

    // 創建支付請求的JSON配置
    private fun createPaymentDataRequest(): JSONObject {
        return JSONObject().apply {
            put("apiVersion", 2) // API主版本
            put("apiVersionMinor", 0) // API次版本

            // 交易信息配置
            val transactionInfo = JSONObject().apply {
                put("totalPrice", "10.00") // 總金額（示例值，應替換為實際金額）
                put("totalPriceStatus", "FINAL") // 金額狀態：FINAL（最終）或ESTIMATED（預估）
                put("countryCode", "TW") // 國家代碼（台灣）
                put("currencyCode", "TWD") // 貨幣代碼（新台幣）
            }

            // 支付方式配置
            val allowedPaymentMethods = JSONArray().put(
                JSONObject().apply {
                    put("type", "CARD") // 卡支付
                    put("parameters", JSONObject().apply {
                        // 允許的認證方式
                        put("allowedAuthMethods", JSONArray(listOf("PAN_ONLY", "CRYPTOGRAM_3DS")))
                        // 允許的卡網絡
                        put("allowedCardNetworks", JSONArray(listOf("AMEX", "DISCOVER", "MASTERCARD", "VISA")))
                    })
                    // 令牌化規格（用於安全處理支付信息）
                    put("tokenizationSpecification", JSONObject().apply {
                        put("type", "PAYMENT_GATEWAY") // 支付閘道類型
                        put("parameters", gatewayTokenizationParameters) // 閘道參數
                    })
                }
            )

            put("allowedPaymentMethods", allowedPaymentMethods)
            put("transactionInfo", transactionInfo)
            // 商家信息配置
            put("merchantInfo", JSONObject().apply {
                put("merchantName", "Example Merchant") // 商家名稱（應替換為實際名稱）
            })
        }
    }

    companion object {
        private const val LOAD_PAYMENT_DATA_REQUEST_CODE = 991 // 支付請求的請求碼
    }
}