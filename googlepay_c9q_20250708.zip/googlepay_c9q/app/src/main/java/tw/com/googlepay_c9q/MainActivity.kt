package tw.com.googlepay_c9q

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val GOOGLE_PAY_REQUEST_CODE = 123
    private val UPI_APPS = listOf(
        "com.google.android.apps.nbu.paisa.user", // Google Pay India
        "com.google.android.apps.walletnfcrel", // Google Wallet
        "com.phonepe.app", // PhonePe
        "net.one97.paytm", // Paytm
        "in.org.npci.upiapp" // BHIM
    )

    private lateinit var btnPay: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        btnPay = findViewById(R.id.btnPay)

        // 記錄已安裝的應用程式以供除錯
        logInstalledApps()

        btnPay.setOnClickListener {
            val uri = Uri.Builder()
                .scheme("upi")
                .authority("pay")
                .appendQueryParameter("pa", "your-vpa@upi") // 替換為實際 VPA
                .appendQueryParameter("pn", "Payee Name") // 替換為實際收款人名稱
                .appendQueryParameter("mc", "1234") // 商家類別代碼
                .appendQueryParameter("tr", "123456789") // 交易 ID
                .appendQueryParameter("tn", "testing payment") // 交易備註
                .appendQueryParameter("am", "10.00") // 金額
                .appendQueryParameter("cu", "INR") // 貨幣
                .appendQueryParameter("url", "https://youtube.com/mihirmodi") // 交易參考 URL
                .build()

            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = uri
            }

            // 檢查是否有應用程式可以處理 UPI Intent
            if (intent.resolveActivity(packageManager) != null) {
                try {
                    startActivityForResult(intent, GOOGLE_PAY_REQUEST_CODE)
                } catch (e: Exception) {
                    Log.e("UPIPayError", "無法啟動 UPI 應用程式: ${e.message}")
                    Toast.makeText(this, "無法啟動 UPI 應用程式: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } else {
                Log.e("UPIPayError", "未安裝任何支援 UPI 的應用程式")
                val message = if (isAppInstalled("com.google.android.apps.walletnfcrel")) {
                    "Google 錢包已安裝，但不支援 UPI 支付。請安裝 Google Pay（印度版）：https://play.google.com/store/apps/details?id=com.google.android.apps.nbu.paisa.user"
                } else {
                    "未檢測到 Google 錢包或任何 UPI 應用程式。請安裝 Google Pay：https://play.google.com/store/apps/details?id=com.google.android.apps.nbu.paisa.user"
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    // 檢查是否安裝了指定的應用程式
    private fun isAppInstalled(packageName: String): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, PackageManager.GET_UNINSTALLED_PACKAGES)
            Log.d("AppCheck", "檢測到應用程式: $packageName")
            true
        } catch (e: PackageManager.NameNotFoundException) {
            Log.d("AppCheck", "未檢測到應用程式: $packageName")
            false
        }
    }

    // 檢查是否有任何 UPI 應用程式安裝
    private fun isAnyUPIAppInstalled(): Boolean {
        return UPI_APPS.any { packageName -> isAppInstalled(packageName) }
    }

    // 記錄所有已安裝的應用程式以供除錯
    private fun logInstalledApps() {
        val packages = packageManager.getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES)
        for (packageInfo in packages) {
            Log.d("InstalledApps", "已安裝應用程式: ${packageInfo.packageName}")
        }
        Log.d("UPIAppCheck", "UPI 應用程式安裝狀態: ${if (isAnyUPIAppInstalled()) "已安裝" else "未安裝"}")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GOOGLE_PAY_REQUEST_CODE) {
            when (resultCode) {
                RESULT_OK -> {
                    val status = data?.extras?.toString() ?: "無返回資料"
                    Log.d("GooglePayResult", "交易結果: $status")
                    Toast.makeText(this, "交易成功: $status", Toast.LENGTH_LONG).show()
                }
                RESULT_CANCELED -> {
                    Log.d("GooglePayResult", "交易已取消")
                    Toast.makeText(this, "交易已取消", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    Log.d("GooglePayResult", "交易失敗或未知結果: $resultCode")
                    Toast.makeText(this, "交易失敗或未知結果: $resultCode", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}